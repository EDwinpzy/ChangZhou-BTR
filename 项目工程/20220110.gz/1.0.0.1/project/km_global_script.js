var $System = KMRunSystemManager.getInstance().get$System();$Function = {systemStart: function() {},systemOn: function() {var system_on = setInterval(function() {}, 4000);KMSystemInterval.getInstance().add(system_on);},systemEnd: function() {},Guid: function() {
/**
 * @description: 生成随机GUID码
 * @return {string} 返回GUID码
 */
return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
    var r = (Math.random() * 16) | 0,
        v = c == 'x' ? r : (r & 0x3) | 0x8;
    return v.toString(16);
});
},GetDataTimeFunc: function() {
/**
 * @description: 获取当前日期时间函数
 * @return {string} 返回格式为"2021-01-11 18:06:53"
 */

    var date = new Date();
    var year = date.getFullYear();
    /* 在日期格式中，月份是从0开始的，因此要加0
     * 使用三元表达式在小于10的前面加0，以达到格式统一  如 09:11:05
     * */
    var month = date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1;
    var day = date.getDate() < 10 ? '0' + date.getDate() : date.getDate();
    var hours = date.getHours() < 10 ? '0' + date.getHours() : date.getHours();
    var minutes = date.getMinutes() < 10 ? '0' + date.getMinutes() : date.getMinutes();
    var seconds = date.getSeconds() < 10 ? '0' + date.getSeconds() : date.getSeconds();
    // 拼接
    return year + '-' + month + '-' + day + ' ' + hours + ':' + minutes + ':' + seconds;

},GetDataFunc: function() {
/**
 * @description: 获取当前日期函数
 * @return {string} 返回格式为"2021-01-11"
 */

    var date = new Date();
    var year = date.getFullYear();
    /* 在日期格式中，月份是从0开始的，因此要加0
     * 使用三元表达式在小于10的前面加0，以达到格式统一  如 09:11:05
     * */
    var month = date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1;
    var day = date.getDate() < 10 ? '0' + date.getDate() : date.getDate();
    // 拼接
    return year + '-' + month + '-' + day;

},sqlDistinct: function(config,field,queryConditions) {
/**
 * @description: 数据去重，代替sql中的distinct
 * @param {object[]} config - 数据源配置信息 ['数据源名称', '数据库表名称']
 * @param {object[]} field - 需要去重的字段名称
 * @param {string} queryConditions - 查询条件语句
 * @return {object[]} 数组对象
 */

var dataBase = config[1];
var result = {};
SyncSQLExecute(config[0], 0, `SELECT * FROM '${dataBase}' '${queryConditions}'`, result);
var data = result.records;
var map = {};
var resData = [];
for (var i = 0; i < data.length; i++) {
    var key = field.join('');
    if (map[key] === undefined) {
        map[key] = 1;
        resData.push(data[i]);
    }
}
return resData;

},sqlGroupby: function(config,field1,field2,field3,queryConditions) {
/**
 * @description: 聚合函数，分组统计，实现GROUP BY SUM功能
 * @param {object[]} config - 数据源配置信息 ['数据源名称', '数据库表名称']
 * @param {object[]} field1 - 需要查出的字段名（SELECT后的字段名称）
 * @param {object[]} field2 - 需要分组的字段名（GROUP BY后的字段名称）
 * @param {object[]} field3 - 需要累加的字段名（后的字段名称）
 * @param {string} queryConditions - 查询条件语句
 * @return {object[]} 数组对象
 */

    var dataBase = config[1];
    var result = {};
    SyncSQLExecute(config[0], 0, `SELECT * FROM '${dataBase}' '${queryConditions}'`, result);
    var data = result.records;
    var map = {};
    var resData = [];
    for (var i = 0; i < data.length; i++) {
        var key = field2.join('');
        if (map[key] === undefined) {
            var t = {};
            field1.forEach(function (item) {
                t[item] = data[i][item];
            });
            t.sumValue = data[field3];
            map[key] = t;
            resData.push(t);
        } else {
            var t = map[key];
            t.sumValue += data[i][field3];
        }
    }
    return resData;

},sqlLeftjoin: function(dataSetLeft,dataSetRight,field) {

   
/*
 * @Author: EDwin
 * @Date: 2021-12-30 08:59:20
 * @LastEditors: Please set LastEditors
 * @LastEditTime: 2021-12-31 10:53:45
 */
/**
 * @description: 数据联合，实现LEFT JOIN功能
 * @param {object[]} dataSetLeft - 左表数据集
 * @param {object[]} dataSetRight - 右表数据集
 * @param {object[]} field - 联合的字段['左表字段', '右表字段']
 * @return {object[]} 数组对象
 */
// function sqlLeftjoin(dataSetLeft, dataSetRight, field) {
    //将右表中与左表同名的字段名称后面加个1
    var leftField = [];
    var rightField = [];
    for (var key in dataSetLeft[0]) {
        leftField.push(key);
    }
    for (var key in dataSetRight[0]) {
        rightField.push(key);
    }
    leftField.forEach(function (item) {
        for (var i = 0; i < rightField; i++) {
            if (item == rightField[i]) {
                copyTrans(dataSetRight, [{ key: rightField[i], value: rightField[i] + '1' }]);
                rightField[i] = rightField[i] + '1';
            }
        }
    });
    //将右表的字段名称加入到左表的对象键名中
    dataSetLeft.forEach(function (item) {
        for (var i = 0; i < rightField; i++) {
            item[rightField[i]] = null;
        }
    });
    var resData = [];
    dataSetLeft.forEach(function (item) {
        //用于判断是否右表有和左表匹配的对象，若没有需要将左表该对象本身插入结果中
        var flag = 0;
        for (var i = 0; i < dataSetRight.length; i++) {
            //ON后面的联合条件
            if (item[field[0]] == dataSetRight[i][field[1]]) {
                flag = 1;
                //将右表对象中的值赋给左表对象
                var obj = item;
                rightField.forEach(function (key) {
                    obj[key] = dataSetRight[i][key];
                });
                resData.push(obj);
            }
        }
        flag === 0 ? resData.push(item) : 1;
    });
    return resData;
// }

},sqlInnerjoin: function(config,field) {
/**
 * @description: 数据联合，实现inner JOIN功能
 * @param {object[]} config - 数据源配置信息 ['数据源名称', '数据库左表名称', '数据库右表名称']
 * @param {object[]} field - 联合的字段['左表字段', '右表字段']
 * @return {object[]} 数组对象
 */
    var result1 = {};
    var result2 = {};
    SyncSQLExecute(config[0], 0, `SELECT * FROM '${config[1]}'`, result1);
    SyncSQLExecute(config[0], 0, `SELECT * FROM '${config[2]}'`, result2);
    var leftData = result1.records;
    var rightData = result2.records;
    //将右表中与左表同名的字段名称后面加个1
    var leftField = [];
    var rightField = [];
    for (var key in leftData[0]) {
        leftField.push(key);
    }
    for (var key in rightData[0]) {
        rightField.push(key);
    }
    leftField.forEach(function (item) {
        for (var i = 0; i < rightField; i++) {
            if (item == rightField[i]) {
                copyTrans(rightData, [{ key: rightField[i], value: rightField[i] + '1' }]);
                rightField[i] = rightField[i] + '1';
            }
        }
    });
    //将右表的字段名称加入到左表的对象键名中
    leftData.forEach(function (item) {
        for (var i = 0; i < rightField; i++) {
            item[rightField[i]] = null;
        }
    });
    var resData = [];
    leftData.forEach(function (item) {
        for (var i = 0; i < rightData.length; i++) {
            //ON后面的联合条件
            if (item[field[0]] == rightData[i][field[1]]) {
                flag = 1;
                //将右表对象中的值赋给左表对象
                var obj = item;
                rightField.forEach(function (key) {
                    obj[key] = rightData[i][key];
                });
                resData.push(obj);
            }
        }
    });
    return resData;
},sqlOrder: function(config,obj,field) {
/**
 * @description: 排序，实现ORDER BY功能
 * @param {object[]} config - 数据源配置信息 ['数据源名称', '数据库表名称']
 * @param {object[object]} obj - 需要排序的数组对象
 * @param {object[object]} field - 排序字段及规则 [{name: '字段名1', rule: 'ASC'}, {name: '字段名2', rule: 'DESC'}]
 * @return {object[]} 数组对象
 */
    var resData = [];
    for (var i = 0; i < field; i++) {
        resData = obj.sort(function (a, b) {
            if (field[i].rule === 'ASC') {
                return a[field[i].name] > b[field[i].name] ? 1 : a[field[i].name] < b[field[i].name] ? -1 : 0;
            } else if (field[i].rule === 'DESC') {
                return a[field[i].name] > b[field[i].name] ? -1 : a[field[i].name] < b[field[i].name] ? 1 : 0;
            }
        });
    }
    return resData;
},copyTrans: function(obj,typeArr) {
/**
 * @description: 修改对象指定的键名
 * 函数本身是一个深拷贝，通过对其每层中对象的“键”做匹配替换即实现了多层的“键”替换，另外这里如果传空数组此函数就是一个深拷贝。
 * @param {object[object]} obj - 需要修改键名的数组对象
 * @param {object[object]} typeArr - [{key: '原键名', value: '修改后的键名'}, {key: '原键名', value: '修改后的键名'}]
 * @return {*}
 */
    let result;
    let toString = Object.prototype.toString;
    if (toString.call(obj) === '[object Array]') {
        result = [];
        for (let i = 0; i < obj.length; i++) {
            result[i] = copyTrans(obj[i], arguments[1]);
        }
    } else if (toString.call(obj) === '[object Object]') {
        result = {};
        for (let _key in obj) {
            if (obj.hasOwnProperty(_key)) {
                let flag = 0,
                    _value = null;
                for (let j = 0; j < arguments[1].length; j++) {
                    if (arguments[1][j].key === _key) {
                        flag = 1;
                        _value = arguments[1][j].value;
                    }
                }
                if (flag) result[_value] = copyTrans(obj[_key], arguments[1]);
                else result[_key] = copyTrans(obj[_key], arguments[1]);
            }
        }
    } else {
        return obj;
    }
    return result;
},getID: function(type) {
/**
 * @description: 获取各种表单、任务编号 规则：类型 + 日期 + 流水号
 * @param {number} type - 编号类型 1:出库单号
 * @return {string} id - 单号
 */
    //单号前缀配置数组
    var config = ['CK'];
    var field = 'num' + type;
    var sqlStr = `SELECT ${field} FROM [dbo].[serial_number] WHERE DT = '${$Function.GetDataFunc()}'`;
    SQLExecute1($System.BTR, 0, sqlStr, function (res) {
        if (res.errorCode == 0) {
            var resData = res.data.records;
            var data = {};
            //将当日流水号加1
            SyncSQLExecute($System.BTR, 1, `UPDATE [dbo].[serial_number] SET num${type} = '${resData[0][field] + 1}' WHERE DT = '${$Function.GetDataFunc()}'`, data);
            if (data.errorCode == 0) {
                var date = new Date();
                var year = date.getFullYear();
                var month = date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1;
                var day = date.getDate() < 10 ? '0' + date.getDate() : date.getDate();
                return config[type - 1] + '-' + year + month + day + '-' + resData[0][field];
            } else {
                return '';
            }
        } else {
            return '';
        }
    });
},QCtaskGenrate: function(taskType,exeCutor,bigBatch,smallBatch,privateTaskObj,rule,dataBase) {
/*
 * @Author: EDwin
 * @Date: 2021-12-10 13:39:42
 * @LastEditors: Please set LastEditors
 * @LastEditTime: 2021-12-20 10:44:53
 * @FilePath: \负极二期\功能模块代码\质检任务生成.js
 */
/**
 * @description: 实现生成原材料质检任务，半成品取样任务，半成品质检任务，成品取样任务，成品质检任务函数
 * @param {Number} taskType - 任务类型 1：原材料质检 2：半成品取样 3：半成品质检 4：成品取样 5：成品质检
 * @param {string} exeCutor - 当前步骤执行人
 * @param {string} bigBatch - 大批次号(若质检规则为全检则该参数为空)
 * @param {string} smallBatch - 小批次号(若质检规则为首检则该参数为空)
 * @param {object} privateTaskObj - 质检任务私有成员对象，根据任务类型需要存入不同的数据
 *                              原材料质检：入库单号，入库时间，供应商名称，供应商代码，物料名称，物料代码，物料型号，规格类型
 *                              半成品取样：工序名称，产线，站点，设备名称，产品代码
 *                              半成品质检：工序名称，产线，站点，设备名称，产品代码
 *                              成品取样：工序名称，产线，站点，设备名称，产品代码
 *                              成品质检：工序名称，产线，站点，设备名称，产品代码
 * @param {object} rule - 质检规则 1：全检 2：首检  {type: 2, intervalNum：10, integer：1}质检规则为首检，每10个小批次取第一个小批次进行质检，向下取整 type：质检规则，intervalNum：取样间隔，integer：取整规则（1为向下取整，2为向上取整）  {type: 1}质检规则为全检
 * @param {object[string]} dataBase - 数据库表完整路径名称(必须包含数据库名称)，第一张表为实时任务表，第二张表为历史任务表，第三张表为原材料批次信息表 ['[贝特瑞负极二期].[dbo].[质检实时任务表]', '[贝特瑞负极二期].[dbo].[质检历史任务表]']
 * @return {number} 0：执行失败 1：执行成功
 */
    var taskId = $Functiontion.Guid();
    var nowData = $Function.GetData;
    var taskNum;
    //查询任务次数和ERP批次号
    var result = {};
    SyncSQLExecute($System.BTR, 0, `SELECT (SELECT COUNT(smallBatch) FROM '${dataBase[1]}' WHERE taskType = '${taskType}') AS Num, (SELECT ERPbatch FROM '${dataBase[2]}' WHERE BTRbigBatch = '${bigBatch}' OR BTRsmallBatch = '${smallBatch}') AS ERPbatch`);
    if (result.errorCode == 0) {
        var data = result.data.records;
        taskNum = data[0].Num + 1;
    } else {
        return;
    }
    var sqlStr = `INSERT INTO '${dataBase[0]}' ([taskid], [tasktype], [taskstatus], [starttime], [exeCutor], [smallBatch], [bigBatch], [privateTaskObj], [taskNum], [rule], [ERPbatch]) VALUES `;
    if (rule.type == 1) {
        //质检规则为全检，不考虑大批次，对所有输入的小批次生成取样和质检任务
        sqlStr += `('${taskId}', '${taskType}', 0, '${nowData}', '${exeCutor}', '${smallBatch}', ${bigBatch}, '${JSON.stringify(privateTaskObj)}', '${taskNum}', '${rule.type}', '${result.records[0].ERPbatch}')`;
        var result1 = {};
        SyncSQLExecute($System.BTR, 1, sqlStr, result1);
        return result1.errorCode == 0 ? 1 : 0;
    } else if (rule.type == 2) {
        //质检规则为首检，从大批次中按质检规则抽取未质检的小批次，生成质检任务
        var sqlStr1 = `SELECT * FROM '${dataBase[2]}' WHERE BTRbigBatch = '${bigBatch}' AND QCresult == '' ORDER BY 包号`;
        var result1 = SyncSQLExecute($System.BTR, 1, sqlStr1, result1);
        if (result1.errorCode == 0) {
            //样本数量
            var data1 = result1.data.records;
            var sampleNum = data1.length;
            //样本数量小于待检数量
            if (sampleNum < rule.content) {
                return 0;
            } else {
                var taskNum;
                switch (rule.integer) {
                    //向下取整
                    case 1:
                        taskNum = Math.floor(sampleNum / rule.intervalNum);
                        break;
                    //向上取整
                    case 2:
                        taskNum = Math.ceil(sampleNum / rule.intervalNum);
                        break;
                }
                for (var i = 0; i < taskNum; i++) {
                    sqlStr += `('${taskId}', '${taskType}', 0, '${nowData}', '${exeCutor}', '${data1[rule.intervalNum * i]}', ${bigBatch}, '${privateTaskObj}', '${taskNum}', '${rule.type}'), `;
                }
                sqlStr.substring(0, sqlStr.length - 2);
                var result2 = {};
                SyncSQLExecute($System.BTR, 1, sqlStr, result2);
                return result2.errorCode == 0 ? 1 : 0;
            }
        } else {
            return 0;
        }
    }
}
},QCtaskExecute: function(taskId,exeCutor,privateResultObj,dataBase,QCresult,updataDatabase) {
/*
 * @Author: EDwin
 * @Date: 2021-12-14 10:42:26
 * @LastEditors: Please set LastEditors
 * @LastEditTime: 2021-12-17 10:56:44
 */
/**
 * @description 质检任务执行函数，将上一步质检流程存入历史表中
 * @param {string} taskId 任务编号
 * @param {string} exeCutor - 当前步骤执行人
 * @param {object[object]} privateResultObj - 质检结果私有成员数组对象，根据任务类型需要存入不同的数据，其中质检结果对象需包含result属性用于存放单个质检项的结果0为不合格1为合格
 * @param {object[string]} dataBase - 数据库表完整路径名称，第一张表为实时任务表，第二张表为历史任务表 ['[贝特瑞负极二期].[dbo].[质检实时任务表]', '[贝特瑞负极二期].[dbo].[质检历史任务表]']
 * @param {string} QCresult - 质检结果 0：不合格 1：合格 若为空则程序根据质检结果私有成员对象中的检测结果自动判定，若为取样任务则填入空值
 * @param {object[object]} - updataDatabase 需要更新质检标志位的数据库信息和字段信息,其中databaseType为更新库类型1：ERP系统（唯一标识为物料凭证和行号），2：仓库WMS系统（唯一标识为）[{tasktype: 1, databaseType: 1, databaseName: '数据库表完整路径名称', QCfield: ['质检结果标志位1', '质检结果标志位2', ...], QCvalue1: ['质检合格更新后的值1', '质检合格更新后的值2', ...], QCvalue2: ['质检不合格更新后的值1', '质检不合格更新后的值2', ...]}, ...]
 * @return {object} {errorcode: 0, message: ''} errorcode错误代码 0：执行成功 1：执行失败
 */
    debugger;
    var nowData = funC.GetDataFunc();
    var err = {};
    SyncSQLExecute($System.BTR, 0, `SELECT * FROM '${dataBase[0]}' WHERE taskid = '${tsakId}'`, err);
    if (err.errorcode == 0) {
        var data = err.data.records;
        if (data.length > 0) {
            //先将实时表里的记录删除，然后插入到历史表中
            var sqlStr = `DELETE FROM '${dataBase[0]}' WHERE taskid = '${taskId}'`;
            var result = {};
            SyncSQLExecute($System.BTR, 1, sqlStr, result);
            if (result.errorCode == 0) {
                //自动判断质检结果
                if (data[0].tasktype !== 2 && data[0].tasktype !== 4 && QCresult == '') {
                    privateResultObj.forEach(function (item) {
                        try{
                            if (item.result == 0) {
                                QCresult = 0;
                                throw new Error('质检不合格');
                            }
                        }
                        catch(e){
                            if(e.message == '质检不合格') throw e
                        }
                    });
                }
                var sqlStr1 = `INSERT INTO '${dataBase[1]}' ([taskid], [tasktype], [taskstatus], [starttime], [QCresult], [exeCutor], [endtime], [smallBatch], [bigBatch], [privateTaskObj], [taskNum], [privateResultObj], [rule], [ERPbatch]) VALUES ('${data.taskid}', '${data.tasktype}', 2, '${data.starttime}', '${QCresult}', '${exeCutor}', '${nowData}', '${data.smallBatch}', '${data.bigBatch}', '${data.privateTaskObj}', '${data.taskNum}', '${JSON.stringify(privateResultObj)}', '${data.rule}', '${data.ERPbatch}')`;
                var result1 = {};
                SyncSQLExecute($System.BTR, 1, sqlStr1, result1);
                if (result1.errorCode == 0) {
                    /*************************更新其他数据库表标志位***********************/
                    switch (data[0].tasktype) {
                        //原材料质检
                        case 1:
                            //获取需要修改的数据库信息
                            var updateDbConfig = [];
                            updataDatabase.forEach(function (item) {
                                item.tasktype == 1 ? updateDbConfig.push(item) : 1;
                            })
                            //更新标志位
                            updateDbConfig.forEach(function (item) {
                                var databaseName = item.databaseName;
                                var QCfield = item.QCfield;
                                var QCvalue = QCresult == 1 ? item.QCvalue1 : item.QCvalue2;
                                var databaseType = item.databaseType;
                                switch (databaseType) {
                                    //ERP系统接口表更新
                                    case 1:
                                        var ERP_sqlStr = `UPDATE '${databaseName}' SET `;
                                        for (var i = 0; i < QCfield.length; i++) {
                                            ERP_sqlStr += `'${QCfield[i]}' = '${QCvalue[i]}', `;
                                        }
                                        ERP_sqlStr.substring(0, ERP_sqlStr.length - 2);
                                        ERP_sqlStr += ` WHERE `;
                                        var result2 = {};
                                        SyncSQLExecute($System.BTR, 1, ERP_sqlStr, result2);
                                        if (result2.errorCode == 0) {
                                            return {
                                                errorCode: 0,
                                                message: '更新成功'
                                        }}else{
                                            return {
                                                errorCode: 1,
                                                message: '更新失败'
                                            }
                                        }
                                        break;
                                    //WMS系统质检任务接口表插入
                                    case 2:
                                        var WMS_sqlStr = `INSERT INTO '${databaseName}' (`;
                                        for (var i = 0; i < QCfield.length; i++) {
                                            WMS_sqlStr += `'${QCfield[i]}', `;
                                        }
                                        WMS_sqlStr.substring(0, WMS_sqlStr.length - 2);
                                        WMS_sqlStr += `) VALUES (`;
                                        for (var i = 0; i < QCvalue.length; i++) {
                                            WMS_sqlStr += `'${QCvalue[i]}', `;
                                        }
                                        WMS_sqlStr.substring(0, WMS_sqlStr.length - 2);
                                        WMS_sqlStr += `)`;
                                        var result2 = {};
                                        SyncSQLExecute($System.BTR, 1, WMS_sqlStr, result2);
                                        if (result2.errorCode == 0) {
                                            return {
                                                errorCode: 0,
                                                message: '更新成功'
                                        }}else{
                                            return {
                                                errorCode: 1,
                                                message: '更新失败'
                                            }
                                        }
                                        break;
                                }
                               
                            })
                    }
                } else {
                    return {
                        errorCode: 1,
                        message: '历史表插入失败  ' + result1.message,
                    };
                }
            } else {
                return {
                    errorCode: 1,
                    message: '实时表任务删除失败 ' + result.message,
                };
            }
        } else {
            return {
                errorCode: 1,
                message: '未找到该条任务信息',
            };
        }
    } else {
        return {
            errorCode: 1,
            message: '实时表任务查询失败  ' + err.message,
        };
    }


},StorageTaskGenerate: function(content) {
/*
 * @Author: EDwin
 * @Date: 2021-12-16 16:51:33
 * @LastEditors: Please set LastEditors
 * @LastEditTime: 2021-12-24 18:35:51
 */
/**
 * @description: 生成各种仓库任务单
 * @param {object[object]} content - 单据内容，格式如下：
 *                                  {
                                        taskid:	        单号（任务编号）
                                        taskstatus:	    任务状态  0：未完成  1：已完成
                                        auditstatus:	审核状态  0：未审核  1：已审核
                                        tasktype:	    任务类型  1：出库单   2：退料单  3：领料单  4：退库单（线边仓退料）5：线边仓出库单  6：产品入库单  7：产品出库单  8：立库入库单  9：立库出库单  10：成品出库单
                                        stocktype:	    物料类型  1：原材料  2：半成品  3：成品  4: 包材
                                        ERPbatch:       ERP批次号（一个ERP订单号对应多个ERP批次号，ERP批次号和MES批次号/ 制令单号/配比单号/工单号一一对应）
                                        ERPorder:	    ERP订单号
                                        jobID:	        制令单号/配比单号（工单号,MES批次号）
                                        jobIDS:	        小批次号
                                        stockcode:	    物料代码
                                        stockmodel:	    物料型号
                                        model:          规格型号
                                        QCresult:	    质检结果  0：未质检  1：合格  2：不合格
                                        startposition:	起始仓位
                                        endposition:	终止仓位
                                        starttime:	    开始时间
                                        endtime:	    结束时间
                                        sponsor:	    发起人
                                        reviewer:	    审核人
                                        executor:	    执行人
                                        weight:	        重量
                                        unit：          单位
                                        station:	    工作中心（工序）
                                        line:       	产线
                                        remark：        备注
                                        privateObj：	私有成员对象
                                        flag1:	        预留标志位1
                                        flag2:	        预留标志位2
                                    }
 * @return {*}
 */
    content.forEach(function (item) {
        var sqlStr = `INSERT INTO [dbo].[storage_task] SET `;
        for (var key in item) {
            sqlStr += `${key} = '${item[key]}',`;
        }
        sqlStr.substring(0, sqlStr.length - 1);
        var data = {};
        SyncSQLExecute($System.BTR, 1, sqlStr, data);
        if (data.errorCode != 0) {
            return {
                errorCode: 1,
                message: 'SQL语句执行错误   ' + sqlStr,
            };
        }
    });
    return {
        errorCode: 0,
        message: '单据生成成功！',
    };
},Fun_EnableCopy: function(arrID) {
/********
 * 函数功能：开启画面复制功能
 * 输入参数：需要开启复制功能的控件ID数组
 * 输出参数：无
 * 版本号： 2021-07-12 创建函数
 * *********/
 if (!$("#selectnone").length) 
{

        var style= document.createElement('style');
        style.id = "selectnone" ;
        style.innerHTML = "";
        for(var i = 0 ; i < arrID.length ; i++){
            var styleStr = `${arrID[i]} div{
                -webkit-user-select:text;
                -moz-user-select:text;
                -o-user-select:text;
                 user-select:text;} \n `;
                style.innerHTML += styleStr ;
        }
        document.getElementsByTagName("head")[0].appendChild(style) ;
}
else{
    var inner = document.getElementById("selectnone").innerHTML;
    for(var i = 0 ; i < arrID.length ; i++){
        if(inner.indexOf(arrID[i]) == -1){
            var styleStr = `${arrID[i]} div{
                -webkit-user-select:text;
                -moz-user-select:text;
                -o-user-select:text;
                 user-select:text;}  \n`;
                inner += styleStr ;
        }
    }    
    document.getElementById("selectnone").innerHTML = inner ;
}
},QCresultBack: function(database,corresPondence) {
/*
 * @Author: EDwin
 * @Date: 2021-12-27 09:40:33
 * @LastEditors: Please set LastEditors
 * @LastEditTime: 2021-12-27 11:24:12
 */
/**
 * @description: 质检结果回传，将结果更新到ERP接口表，WMS接口表，MES内部库存表
 * @param {object[string]} database - 回传数据库表名完整路径，如[{sources: '数据源名称', name: '接口表1完整路径'},{sources: '数据源名称', name: '接口表2完整路径'}, ...]
 * @param {object[object[string]]} corresPondence - 更新字段对应关系二维数组
 *                                                  [
                                                        ['更新模式（insert或者update,第一行随便写）', '质检结果检索条件值1（value）', '质检结果值(value)', '质检结果值(value)', '质检结果值(value)', '质检结果值(value)', '质检结果值(value)'],
                                                        ['更新模式（insert或者update,第一行随便写）', '回传结果检索条件字段1（field，若为insert方式此项可不填）', '回传结果字段2（可为空,field）', '回传结果字段3（可为空,field）', '回传结果字段4（可为空,field）', '回传结果字段5（可为空,field）', '回传结果字段6（可为空,field）'],
                                                        ['更新模式（insert或者update,第一行随便写）', '回传结果检索条件字段1（field，若为insert方式此项可不填）', '回传结果字段2（可为空,field）', '回传结果字段3（可为空,field）', '回传结果字段4（可为空,field）', '回传结果字段5（可为空,field）', '回传结果字段6（可为空,field）'],
                                                    ];
 * @return {object} 执行结果{errorCode: 0, message: ''} 0：成功 1：完全失败 2：部分失败
 */
    var result = { errorCode: 0, message: '' };
    try {
        //校验输入参数
        if (corresPondence.length - database.length != 1) throw '数据库表数量和更新字段数量不一致！';
        //对每个回传数据库表进行更新
        for (var i = 0; i < database.length; i++) {
            if (corresPondence[i + 1][0].toLowerCase() == 'UPDATE'.toLowerCase()) {
                //回传模式为更新
                var sqlStr = `UPDATE ${database[i].name} SET `;
                //筛选二维数组中为空的
                for (var j = 2; j < corresPondence[i + 1].length; j++) {
                    //若不为空则需要更新该字段
                    corresPondence[i + 1][j] != '' ? `${corresPondence[i + 1][j]} = '${corresPondence[0][j]}',` : 1;
                }
                sqlStr.substring(0, sqlStr.length - 1);
                var res = {};
                SyncSQLExecute(database[i].source, 1, sqlStr, res);
                if (res.errorCode != 0) {
                    result.errorCode = 2;
                    result.message += database[i].name + '更新失败！  ';
                }
            } else if (corresPondence[i + 1][0].toLowerCase() == 'update'.toLowerCase()) {
                //回传模式为插入
                var arr1 = []; //不为的空字段名
                var arr2 = []; //不为空的值
                //生成插入内容的二维数组（剔除掉corresPondence中为空的）
                for (var j = 0; j < corresPondence[i + 1].length; j++) {
                    if (corresPondence[i + 1][j] == '') {
                        arr1.push(corresPondence[i + 1][j]);
                        arr2.push(corresPondence[0][j]);
                    }
                }
                var sqlStr = `INSERT INTO ${database[i].name} (`;
                arr1.forEach(function (item) {
                    sqlStr += `${item},`;
                });
                sqlStr.substring(0, sqlStr.length - 1);
                sqlStr += `) VALUES (`;
                arr2.forEach(function (item) {
                    sqlStr += `'${item}',`;
                });
                sqlStr.substring(0, sqlStr.length - 1);
                sqlStr += `)`;
                var res = {};
                SyncSQLExecute(database[i].source, 1, sqlStr, res);
                if (res.errorCode != 0) {
                    result.errorCode = 2;
                    result.message += database[i].name + '更新失败！  ';
                }
            } else {
                result.errorCode = 2;
                result.message += database[i].name + ' 更新模式有误，请检查第二个参数！  ';
                break;
            }
        }
    } catch (e) {
        result.errorCode = 1;
        result.message = e;
    } finally {
        return result;
    }


},toDataSet: function(dataSource,sqlStr) {
/**
 *@description:将数据库查询结果返回数据集，只能执行SEECT语句
 *@param{string}dataSource-数据源名称
 *@param{string}sqlStr-SQL查询语句
 *@return{*}数据集数组对象，若查询失败则返回false且弹窗提示
 */
// function toDataSet(dataSource, sqlStr) {
    //select校验
    var reg = eval('/' + 'select' + '/ig');
    if (reg.test(sqlStr)) {
        var res;
        SyncSQLExecute(dataSource, 0, sqlStr, res);
        if (res.errorCode === 0) {
            var data = res.data.records;
            if (data.length === 0) {
                ShowMessage({
                    message: '查询无数据！',
                    type: 'warning',
                    duration: 3000
                });
            }
            return data;
        } else {
            ShowMessage({
                message: '查询失败！请重试！',
                type: 'warning',
                duration: 3000
            });
            return;
        }
    } else {
        return;
    }
// }
},toMap: function(primaryKey,dataSet) {
/**
 *@description:将数据集转换成字典MAP
 *@param{object[string]}primaryKey-主键名数组
 *@param{object[object]}dataSet-数据集
 *@return{map}返回字典，若失败则返回false
 */
// function toMap(primaryKey, dataSet) {
    if (primary.length > 0) {
        var map = {};
        dataSet.forEach(function(item) {
            var key = primaryKey.join('');
            map[key] = item;
        });
        return map;
    } else {
        return;
    }
// }
},tipconfirmtitle: function(title,msg,callback) {
var msg1;
switch (msg) {
    case undefined:
        msg1 = '是否删除该数据？';
        // if(type===undefined)
        // {type='warning';}
        break;
    default:
        msg1 = msg;
}
var options =
{
    title: title,
    type: 'warning',
    message: msg1,
    confirmButtonText: '确认',//确认文本
    cancelButtonText: '取消',//取消文本
};
ShowMsgBox('confirm', options, function (res) {
    if(res.action === 'confirm'){
        callback();
    }
    //return res;
});

var cssstype1 = $(".el-message-box");
cssstype1.eq(cssstype1.length - 1).attr('class', 'el-message-box typecss1');
if ($("#tipStyle").length) {
    $("#tipStyle").remove();
}
var style = document.createElement('style');
style.id = 'tipStyle';
var styleText = `.typecss1 .el-message-box__title{
    font-size:16px !important;
    border-bottom: 4px solid #F1F1F1;
    padding-bottom: 6px;
    font-family: "微软雅黑";
    font-Weight: normal;
    color:#111111;
    
}
.typecss1 .el-button--small, .el-button--small.is-round {
    padding: 9px 18px;
}
.typecss1 .el-message-box { 
padding-bottom: 13px;
}
.typecss1 .el-icon-close:before {
    padding-right: 13px;
}
.typecss1 .el-message-box__btns {
    padding: 5px 30px 0;
    text-align: right;
}
.typecss1 .el-message-box__btns button:nth-child(2) {
    margin-left: 24px;
}
.typecss1 .el-message-box__content {
    padding: 10px 30px;
}
.typecss1 .el-message-box__header {
    position: relative;
    padding: 13px 30px 10px;
}

.typecss1 .el-message-box__content{
    font-size: 14px
    font-family: "微软雅黑";
    font-Weight: normal;
    color:#333333;
}`;
style.innerHTML = styleText;
document.getElementsByTagName('head')[0].appendChild(style);
},tip: function(type,msg) {
var msg1, type1;
var duration1=1500;
switch (msg) {
    case undefined:
        msg1 = '提交成功';
        if (type === undefined) { type = 'success'; }
        break;
    default:
        msg1 = msg;
}

switch (type) {
    case undefined:
        type1 = 'info';
        break;
    case 'success':
        type1 = type;
        break;
    case 'error':
        type1 = type;
        duration1=4000;
        break;
    case 'warning':
        type1 = type;
        duration1=2500;
        break;
    default:
        type1 = 'info';
}

var options =
{
    type: type1,
    message: msg1,
    offset: 20,
    duration: duration1,
    showClose: true,
};
ShowMessage(options);
return;
},OcxFiltering: function(OCX,dataSet) {
/*
 * @Author: EDwin
 * @Date: 2021-12-29 17:40:18
 * @LastEditors: Please set LastEditors
 * @LastEditTime: 2022-01-04 10:00:24
 */
/**
 * @description: 按控件内容筛选函数
 * @param {object[object]} OCX - 控件名称及对应的字段名 [{name: 'Combobox1', field: 'taskID', match: '='}, ...] 匹配条件可为 =、!=、<、>、<=、>=、like（模糊查询）
 * @param {object[object]} dataSet - 数据集
 * @return {object[object]} 筛选后的数据集
 */
// function OcxFiltering(OCX, dataSet) {
    var condition = [];
    for (var i = 0; i < OCX.length; i++) {
        //控件名字
        var OCXName = OCX[i].name;
        var obj = {
            field: OCX[i].field,
            match: OCX[i].match,
        };
        //判断控件类型  Combobox Textbox UIRadioButtonGroup DateBox DateTimeBox
        switch (this.$ParentChildren[OCXName].prototypeName) {
            case 'Combobox':
                obj.value = eval(OCXName).GetCurrentText();
                break;
            case 'Textbox':
                obj.value = eval(OCXName).Text;
                break;
            case 'UIRadioButtonGroup':
                obj.value = eval(OCXName).SelectedText;
                break;
            case 'DateBox':
                obj.value = eval(OCXName).Value;
                break;
            case 'DateTimeBox':
                obj.value = eval(OCXName).Value;
                break;
            default:
                return;
        }
        condition.push(obj);
    }
    for (var j = 0; j < condition.length; j++) {
        if (condition[j].value == '全部') {
            break;
        } else {
            switch (condition[j].match) {
                case '=':
                    for (var i = 0; i < dataSet.length; i++) {
                        if (dataSet[i][condition[j].field] != condition[j].value) {
                            dataSet.splice(i, 1);
                        }
                    }
                    break;
                case '!=':
                    for (var i = 0; i < dataSet.length; i++) {
                        if (dataSet[i][condition[j].field] == condition[j].value) {
                            dataSet.splice(i, 1);
                        }
                    }
                    break;
                case '>':
                    for (var i = 0; i < dataSet.length; i++) {
                        if (dataSet[i][condition[j].field] <= condition[j].value) {
                            dataSet.splice(i, 1);
                        }
                    }
                    break;
                case '>=':
                    for (var i = 0; i < dataSet.length; i++) {
                        if (dataSet[i][condition[j].field] < condition[j].value) {
                            dataSet.splice(i, 1);
                        }
                    }
                    break;
                case '<':
                    for (var i = 0; i < dataSet.length; i++) {
                        if (dataSet[i][condition[j].field] >= condition[j].value) {
                            dataSet.splice(i, 1);
                        }
                    }
                    break;
                case '<=':
                    for (var i = 0; i < dataSet.length; i++) {
                        if (dataSet[i][condition[j].field] > condition[j].value) {
                            dataSet.splice(i, 1);
                        }
                    }
                    break;
                case 'like':
                    for (var i = 0; i < dataSet.length; i++) {
                        var reg = eval('/' + condition[j].value + '/ig');
                        if (!reg.test(dataSet[i][condition[j].field])) {
                            dataSet.splice(i, 1);
                        }
                    }
                    break;
            }
        }
    }
    return dataSet;
// }
},CloseProductOrder: function(jobID,mode) {
/*
 * @Author: EDwin
 * @Date: 2021-12-28 15:08:31
 * @LastEditors: Please set LastEditors
 * @LastEditTime: 2021-12-29 17:49:41
 */
/**
 * @description: 工单关闭/废弃函数，更新工单信息表productOrder_realTime的标志位，并将工单信息表productOrder_realTime、投料实时表put_realTime、收料实时表get_realTime 存如历史表中，并删除实时表中的数据。
 * @param {string} jobID - 制令单号/配比单号（工单号,MES批次号）
 * @param {number} mode - 0：完成后关闭 1：废弃（取消）
 * @return {object} {errorCode: 0, message: ''}
 */
// function CloseProductOrder(jobID, mode) {
    try {
        var config = [
            ['productOrder_realTime', 'put_realTime', 'get_realTime'],
            ['productOrder_history', 'put_history', 'get_history'],
        ];
        var result = {
            errorCode: 0,
            message: '',
        };
        var res = {};
        var status;
        if (mdoe == 0) {
            status = 3;
        } else if (mode == 1) {
            status = 4;
        } else {
            throw '输入第二个参数有误！';
        }
        //更新工单实时表productOrder_realTime标志位
        SyncSQLExecute($System.BTR, 1, `UPDATE ${config[0][0]} SET status = '${status}', realEndTime = '${$Function.GetDataTimeFunc()}' WHERE jobID = '${jobID}'`, res);
        if (res.errorCode != 0) throw '工单信息表' + config[0][0] + '标志位更新失败！';
        //将工单实时表数据插入历史表并删除原数据
        SyncSQLExecute($System.BTR, 1, `INSERT INTO ${config[1][0]} SELECT * FROM ${config[0][0]} WHERE jobID = '${jobID}'`, res);
        if (res.errorCode != 0) throw '工单信息历史表' + config[1][0] + '插入失败！';
        SyncSQLExecute($System.BTR, 1, `DELETE FROM ${config[0][0]} WHERE jobID = '${jobID}'`, res);
        if (res.errorCode != 0) throw '工单信息表' + config[0][0] + '删除失败！';
        //更新投料实时表标志位
        SyncSQLExecute($System.BTR, 1, `UPDATE ${config[0][1]} SET status = '${status}', actualDateTime = '${$Function.GetDataTimeFunc()}' WHERE jobID = '${jobID}'`, res);
        if (res.errorCode != 0) throw '投料实时表' + config[0][1] + '标志位更新失败！';
        //将投料实时表数据插入历史表并删除原数据
        SyncSQLExecute($System.BTR, 1, `INSERT INTO ${config[1][1]} SELECT * FROM ${config[0][1]} WHERE jobID = '${jobID}'`, res);
        if (res.errorCode != 0) throw '投料历史表' + config[1][1] + '插入失败！';
        SyncSQLExecute($System.BTR, 1, `DELETE FROM ${config[0][1]} WHERE jobID = '${jobID}'`, res);
        if (res.errorCode != 0) throw '投料实时表' + config[0][1] + '删除失败！';
        //更新收料实时表标志位
        SyncSQLExecute($System.BTR, 1, `UPDATE ${config[0][2]} SET status = '${status}', actualDateTime = '${$Function.GetDataTimeFunc()}' WHERE jobID = '${jobID}'`, res);
        if (res.errorCode != 0) throw '投料实时表' + config[0][2] + '标志位更新失败！';
        //将收料实时表数据插入历史表并删除原数据
        SyncSQLExecute($System.BTR, 1, `INSERT INTO ${config[1][2]} SELECT * FROM ${config[0][2]} WHERE jobID = '${jobID}'`, res);
        if (res.errorCode != 0) throw '收料历史表' + config[1][2] + '插入失败！';
        SyncSQLExecute($System.BTR, 1, `DELETE FROM ${config[0][2]} WHERE jobID = '${jobID}'`, res);
        if (res.errorCode != 0) throw '收料实时表' + config[0][2] + '删除失败！';
    } catch (e) {
        result.errorCode = 1;
        result.message = e;
    } finally {
        return result;
    }
// }
},};